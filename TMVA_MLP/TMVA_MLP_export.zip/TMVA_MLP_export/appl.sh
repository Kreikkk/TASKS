# gnome-terminal -- python main.py out1
# gnome-terminal -- python main.py out2
# gnome-terminal -- python main.py out3
# gnome-terminal -- python main.py out4
# gnome-terminal -- python main.py out5
# gnome-terminal -- python main.py out6

# gnome-terminal -- python main.py out7
# gnome-terminal -- python main.py out8
# gnome-terminal -- python main.py out9
# gnome-terminal -- python main.py out10
# gnome-terminal -- python main.py out11
# gnome-terminal -- python main.py out12

# gnome-terminal -- python main.py out13
# gnome-terminal -- python main.py out14
# gnome-terminal -- python main.py out15
# gnome-terminal -- python main.py out16
# gnome-terminal -- python main.py out17
# gnome-terminal -- python main.py out18


# gnome-terminal -- python main.py out19
# gnome-terminal -- python main.py out20
# gnome-terminal -- python main.py out21
# gnome-terminal -- python main.py out22
# gnome-terminal -- python main.py out23
# gnome-terminal -- python main.py out24

# gnome-terminal -- python main.py out25
# gnome-terminal -- python main.py out26
# gnome-terminal -- python main.py out27
# gnome-terminal -- python main.py out28
# gnome-terminal -- python main.py out29
# gnome-terminal -- python main.py out30

# gnome-terminal -- python main.py out31
# gnome-terminal -- python main.py out32
# gnome-terminal -- python main.py out33
# gnome-terminal -- python main.py out34
# gnome-terminal -- python main.py out35
# gnome-terminal -- python main.py out36


# gnome-terminal -- python main.py out37
# gnome-terminal -- python main.py out38
# gnome-terminal -- python main.py out39
# gnome-terminal -- python main.py out40
# gnome-terminal -- python main.py out41
# gnome-terminal -- python main.py out42

# gnome-terminal -- python main.py out43
# gnome-terminal -- python main.py out44
# gnome-terminal -- python main.py out45
# gnome-terminal -- python main.py out46
# gnome-terminal -- python main.py out47
# gnome-terminal -- python main.py out48

# gnome-terminal -- python main.py out49
# gnome-terminal -- python main.py out50
# gnome-terminal -- python main.py out51
# gnome-terminal -- python main.py out52
# gnome-terminal -- python main.py out53
# gnome-terminal -- python main.py out54
