# STAGE 1
# gnome-terminal -- python gen.py out1 0.02 N,N 3
# gnome-terminal -- python gen.py out2 0.02 N+5,N 3
# gnome-terminal -- python gen.py out3 0.02 N+10,N 3
# gnome-terminal -- python gen.py out4 0.02 N+5,N+5 3
# gnome-terminal -- python gen.py out5 0.02 N+10,N+5 3
# gnome-terminal -- python gen.py out6 0.02 N+10,N+10 3

# gnome-terminal -- python gen.py out7 0.02 N 3
# gnome-terminal -- python gen.py out8 0.02 N+5 3
# gnome-terminal -- python gen.py out9 0.02 N+10 3
# gnome-terminal -- python gen.py out10 0.01 N,N 3
# gnome-terminal -- python gen.py out11 0.01 N+5,N 3
# gnome-terminal -- python gen.py out12 0.01 N+10,N 3

# gnome-terminal -- python gen.py out13 0.01 N+5,N+5 3
# gnome-terminal -- python gen.py out14 0.01 N+10,N+5 3
# gnome-terminal -- python gen.py out15 0.01 N+10,N+10 3
# gnome-terminal -- python gen.py out16 0.01 N 3
# gnome-terminal -- python gen.py out17 0.01 N+5 3
# gnome-terminal -- python gen.py out18 0.01 N+10 3


# gnome-terminal -- python gen.py out19 0.02 N,N 5
# gnome-terminal -- python gen.py out20 0.02 N+5,N 5
# gnome-terminal -- python gen.py out21 0.02 N+10,N 5
# gnome-terminal -- python gen.py out22 0.02 N+5,N+5 5
# gnome-terminal -- python gen.py out23 0.02 N+10,N+5 5
# gnome-terminal -- python gen.py out24 0.02 N+10,N+10 5

# gnome-terminal -- python gen.py out25 0.02 N 5
# gnome-terminal -- python gen.py out26 0.02 N+5 5
# gnome-terminal -- python gen.py out27 0.02 N+10 5
# gnome-terminal -- python gen.py out28 0.01 N,N 5
# gnome-terminal -- python gen.py out29 0.01 N+5,N 5
# gnome-terminal -- python gen.py out30 0.01 N+10,N 5

# gnome-terminal -- python gen.py out31 0.01 N+5,N+5 5
# gnome-terminal -- python gen.py out32 0.01 N+10,N+5 5
# gnome-terminal -- python gen.py out33 0.01 N+10,N+10 5
# gnome-terminal -- python gen.py out34 0.01 N 5
# gnome-terminal -- python gen.py out35 0.01 N+5 5
# gnome-terminal -- python gen.py out36 0.01 N+10 5


# gnome-terminal -- python gen.py out37 0.02 N,N 7
# gnome-terminal -- python gen.py out38 0.02 N+5,N 7
# gnome-terminal -- python gen.py out39 0.02 N+10,N 7
# gnome-terminal -- python gen.py out40 0.02 N+5,N+5 7
# gnome-terminal -- python gen.py out41 0.02 N+10,N+5 7
# gnome-terminal -- python gen.py out42 0.02 N+10,N+10 7

# gnome-terminal -- python gen.py out43 0.02 N 7
# gnome-terminal -- python gen.py out44 0.02 N+5 7
# gnome-terminal -- python gen.py out45 0.02 N+10 7
# gnome-terminal -- python gen.py out46 0.01 N,N 7
# gnome-terminal -- python gen.py out47 0.01 N+5,N 7
# gnome-terminal -- python gen.py out48 0.01 N+10,N 7

# gnome-terminal -- python gen.py out49 0.01 N+5,N+5 7
# gnome-terminal -- python gen.py out50 0.01 N+10,N+5 7
# gnome-terminal -- python gen.py out51 0.01 N+10,N+10 7
# gnome-terminal -- python gen.py out52 0.01 N 7
# gnome-terminal -- python gen.py out53 0.01 N+5 7
# gnome-terminal -- python gen.py out54 0.01 N+10 7
